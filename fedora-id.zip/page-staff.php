<?php 

/**
 * Template Name: Staff Page
 *
 * @package fedoraid
 */


get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<div class="container">
				<div class="row">
					<div class="col s3">
						xxx
					</div>
					<div class="col s3">
						xxx
					</div>
					<div class="col s3">
						xxx
					</div>
					<div class="col s3">
						xxx
					</div>
				</div>
			</div>
		</main>
	</div>
				


					
					